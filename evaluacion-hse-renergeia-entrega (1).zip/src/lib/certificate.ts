import { promises as fs } from "node:fs";
import path from "node:path";
import {
  PDFDocument,
  StandardFonts,
  rgb,
  type PDFFont,
  type PDFPage,
} from "pdf-lib";
import type { Intento } from "./types";

// Colores de marca Renergeia.
const VERDE = rgb(0x5c / 255, 0xb6 / 255, 0x4a / 255);
const AZUL = rgb(0x1f / 255, 0x3a / 255, 0x5f / 255);
const GRIS = rgb(0.35, 0.35, 0.35);

function fechaLarga(iso: string): string {
  const meses = [
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
  ];
  const d = new Date(iso);
  return `${d.getDate()} de ${meses[d.getMonth()]} de ${d.getFullYear()}`;
}

/** Dibuja un texto centrado horizontalmente en la página. */
function textoCentrado(
  page: PDFPage,
  texto: string,
  y: number,
  font: PDFFont,
  size: number,
  color = AZUL,
): void {
  const ancho = font.widthOfTextAtSize(texto, size);
  page.drawText(texto, {
    x: (page.getWidth() - ancho) / 2,
    y,
    size,
    font,
    color,
  });
}

/** Genera el certificado de aprobación en PDF y lo devuelve como bytes. */
export async function generarCertificado(intento: Intento): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  // Horizontal tipo diploma (A4 apaisado).
  const page = pdf.addPage([842, 595]);
  const { width, height } = page.getSize();

  const fontRegular = await pdf.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const fontItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);

  // Marco decorativo.
  page.drawRectangle({
    x: 20, y: 20, width: width - 40, height: height - 40,
    borderColor: VERDE, borderWidth: 3,
  });
  page.drawRectangle({
    x: 28, y: 28, width: width - 56, height: height - 56,
    borderColor: AZUL, borderWidth: 1,
  });

  // Logo centrado arriba.
  try {
    const logoBytes = await fs.readFile(
      path.join(process.cwd(), "public", "logo-renergeia.png"),
    );
    const logo = await pdf.embedPng(logoBytes);
    const logoAncho = 180;
    const logoAlto = (logo.height / logo.width) * logoAncho;
    page.drawImage(logo, {
      x: (width - logoAncho) / 2,
      y: height - 60 - logoAlto,
      width: logoAncho,
      height: logoAlto,
    });
  } catch {
    // Si no está el logo, seguimos sin él.
  }

  const nombre =
    `${intento.participante.nombre} ${intento.participante.apellido}`.trim();

  textoCentrado(page, "CERTIFICADO DE APROBACIÓN", height - 200, fontBold, 26, AZUL);
  textoCentrado(page, "Se certifica que", height - 240, fontItalic, 14, GRIS);
  textoCentrado(page, nombre.toUpperCase(), height - 280, fontBold, 24, VERDE);
  textoCentrado(
    page,
    `identificado(a) con cédula ${intento.participante.cedula}`,
    height - 306,
    fontRegular,
    13,
    GRIS,
  );

  textoCentrado(
    page,
    "aprobó satisfactoriamente la capacitación",
    height - 342,
    fontRegular,
    14,
    AZUL,
  );
  textoCentrado(page, `"${intento.tema}"`, height - 372, fontBold, 18, AZUL);

  textoCentrado(
    page,
    `Calificación obtenida: ${intento.nota.toFixed(1)} / 5.0`,
    height - 410,
    fontBold,
    15,
    VERDE,
  );

  textoCentrado(
    page,
    `Expedido el ${fechaLarga(intento.presentadoEn)}`,
    height - 445,
    fontItalic,
    12,
    GRIS,
  );

  // Pie: línea de firma institucional.
  const firmaY = 90;
  const firmaAncho = 220;
  const firmaX = (width - firmaAncho) / 2;
  page.drawLine({
    start: { x: firmaX, y: firmaY },
    end: { x: firmaX + firmaAncho, y: firmaY },
    thickness: 1,
    color: AZUL,
  });
  textoCentrado(page, "RENERGEIA — Sustainable Projects", firmaY - 16, fontRegular, 11, GRIS);
  textoCentrado(page, "Sistema de Gestión SST", firmaY - 30, fontRegular, 9, GRIS);

  // Identificador del intento para verificación.
  page.drawText(`ID: ${intento.id}`, {
    x: 40, y: 40, size: 7, font: fontRegular, color: GRIS,
  });

  return pdf.save();
}

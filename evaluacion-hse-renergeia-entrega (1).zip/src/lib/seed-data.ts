import type { Evaluacion, PreguntaFeedback } from "./types";

/** Preguntas de retroalimentación estándar del formato FO-SG-SS-100-1. */
export const FEEDBACK_ESTANDAR: PreguntaFeedback[] = [
  {
    id: "fb1",
    enunciado: "¿El nivel del manejo del tema del capacitador fue?",
    escala: "cualitativa",
  },
  {
    id: "fb2",
    enunciado: "¿La metodología ayudó con la comprensión del tema?",
    escala: "cualitativa",
  },
  {
    id: "fb3",
    enunciado: "¿Dio atención y respuesta a sus dudas y preguntas?",
    escala: "cualitativa",
  },
  {
    id: "fb4",
    enunciado: "¿Cómo califica al capacitador? (5 muy bueno, 1 muy malo)",
    escala: "numerica",
  },
  {
    id: "fb5",
    enunciado:
      "Califique las condiciones de espacio, confort y temperatura del sitio de capacitación.",
    escala: "numerica",
  },
];

/** Evaluación inicial: Hábitos y estilos de vida saludables. */
export const EVALUACION_HABITOS_SALUDABLES: Evaluacion = {
  id: "habitos-vida-saludable",
  titulo: "Evaluación — Hábitos y estilos de vida saludables",
  tema: "Hábitos y estilos de vida saludables",
  descripcion:
    "Evaluación de la capacitación en hábitos y estilos de vida saludables (SG-SST).",
  activa: true,
  creadaEn: new Date().toISOString(),
  actualizadaEn: new Date().toISOString(),
  feedback: FEEDBACK_ESTANDAR,
  preguntas: [
    {
      id: "p1",
      enunciado:
        "¿Cuál de las siguientes acciones contribuye de manera más efectiva a la prevención de enfermedades cardiovasculares?",
      opciones: [
        { id: "a", texto: "Consumir bebidas energizantes para mantener la actividad diaria." },
        { id: "b", texto: "Realizar actividad física regularmente, mantener una alimentación saludable y controlar la presión arterial." },
      ],
      correcta: "b",
    },
    {
      id: "p2",
      enunciado:
        "¿Cuál es uno de los principales beneficios de mantener una adecuada higiene del sueño?",
      opciones: [
        { id: "a", texto: "Incrementar el consumo de alimentos durante la noche." },
        { id: "b", texto: "Mejorar la recuperación física y mental, favoreciendo el rendimiento laboral." },
      ],
      correcta: "b",
    },
    {
      id: "p3",
      enunciado:
        "¿Cuál de los siguientes alimentos aporta vitaminas, minerales y antioxidantes que favorecen la salud?",
      opciones: [
        { id: "a", texto: "Frutas y verduras frescas." },
        { id: "b", texto: "Bebidas azucaradas y productos ultraprocesados." },
      ],
      correcta: "a",
    },
    {
      id: "p4",
      enunciado:
        "Durante la jornada laboral, ¿las pausas activas tienen como objetivo principal?",
      opciones: [
        { id: "a", texto: "Aumentar el tiempo de descanso sin movimiento." },
        { id: "b", texto: "Reducir la fatiga, mejorar la circulación y disminuir el riesgo de lesiones musculoesqueléticas." },
      ],
      correcta: "b",
    },
    {
      id: "p5",
      enunciado: "¿Qué se considera un hábito saludable para prevenir el sedentarismo?",
      opciones: [
        { id: "a", texto: "Permanecer sentado durante toda la jornada laboral." },
        { id: "b", texto: "Levantarse y moverse al menos cada hora, realizando caminatas cortas o estiramientos." },
      ],
      correcta: "b",
    },
    {
      id: "p6",
      enunciado:
        "¿Cuál es la recomendación general para mantener una buena salud mediante la actividad física?",
      opciones: [
        { id: "a", texto: "Realizar actividad física solo los fines de semana." },
        { id: "b", texto: "Realizar al menos 150 minutos de actividad física moderada a la semana, complementada con ejercicios de fortalecimiento muscular." },
      ],
      correcta: "b",
    },
  ],
};

import type { Admin, Evaluacion, Intento } from "./types";

/**
 * Contrato del almacén de datos. Permite dos implementaciones intercambiables:
 * - JSON local (desarrollo)
 * - Firestore (producción en Cloud Run)
 * Seleccionadas por la variable de entorno DB_BACKEND.
 */
export interface DataStore {
  // Evaluaciones
  listEvaluaciones(): Promise<Evaluacion[]>;
  listEvaluacionesActivas(): Promise<Evaluacion[]>;
  getEvaluacion(id: string): Promise<Evaluacion | null>;
  saveEvaluacion(evaluacion: Evaluacion): Promise<void>;
  deleteEvaluacion(id: string): Promise<void>;

  // Intentos
  createIntento(intento: Intento): Promise<void>;
  listIntentos(): Promise<Intento[]>;
  getIntento(id: string): Promise<Intento | null>;
  /** Último intento de una cédula en una evaluación (para la regla de reintento). */
  getUltimoIntento(
    evaluacionId: string,
    cedula: string,
  ): Promise<Intento | null>;

  // Administradores
  getAdmin(username: string): Promise<Admin | null>;
  saveAdmin(admin: Admin): Promise<void>;
}

let cached: DataStore | null = null;

/** Devuelve el almacén de datos configurado (singleton). */
export async function getStore(): Promise<DataStore> {
  if (cached) return cached;
  const backend = process.env.DB_BACKEND ?? "json";
  if (backend === "firestore") {
    const { FirestoreStore } = await import("./db-firestore");
    cached = new FirestoreStore();
  } else {
    const { JsonStore } = await import("./db-json");
    cached = new JsonStore();
  }
  return cached;
}

import Topbar from "@/components/Topbar";
import AdminNav from "@/components/AdminNav";
import TablaResultados from "@/components/TablaResultados";
import { getStore } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const store = await getStore();
  const [intentos, evaluaciones] = await Promise.all([
    store.listIntentos(),
    store.listEvaluaciones(),
  ]);

  const total = intentos.length;
  const aprobados = intentos.filter((i) => i.aprobado).length;
  const reprobados = total - aprobados;
  const tasa = total > 0 ? Math.round((aprobados / total) * 100) : 0;

  return (
    <>
      <Topbar subtitulo="Panel de administración" />
      <main className="container-wide">
        <AdminNav activo="resultados" />
        <h1>Resultados de evaluaciones</h1>

        <div className="stat-grid">
          <div className="stat">
            <div className="num">{total}</div>
            <div className="lbl">Evaluaciones presentadas</div>
          </div>
          <div className="stat">
            <div className="num">{aprobados}</div>
            <div className="lbl">Aprobados</div>
          </div>
          <div className="stat">
            <div className="num" style={{ color: "var(--rojo)" }}>
              {reprobados}
            </div>
            <div className="lbl">Reprobados</div>
          </div>
          <div className="stat">
            <div className="num">{tasa}%</div>
            <div className="lbl">Tasa de aprobación</div>
          </div>
        </div>

        <TablaResultados intentos={intentos} evaluaciones={evaluaciones} />
      </main>
    </>
  );
}

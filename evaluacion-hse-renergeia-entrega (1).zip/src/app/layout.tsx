import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Evaluaciones HSE — Renergeia",
  description:
    "Sistema de evaluación de capacitaciones en salud, seguridad y ambiente de Renergeia.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

interface Fila {
  id: string;
  titulo: string;
  tema: string;
  activa: boolean;
  numPreguntas: number;
}

export default function ListaEvaluaciones({
  evaluaciones,
}: {
  evaluaciones: Fila[];
}) {
  const router = useRouter();
  const [creando, setCreando] = useState(false);

  async function crear() {
    setCreando(true);
    const res = await fetch("/api/admin/evaluations", { method: "POST" });
    const data = await res.json();
    if (data.id) router.push(`/admin/evaluaciones/${data.id}`);
    else setCreando(false);
  }

  async function eliminar(id: string, titulo: string) {
    if (!confirm(`¿Eliminar la evaluación "${titulo}"? Esta acción no se puede deshacer.`))
      return;
    await fetch(`/api/admin/evaluations/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <>
      <button
        className="btn btn-primary"
        onClick={crear}
        disabled={creando}
        style={{ marginBottom: 18 }}
      >
        {creando ? "Creando…" : "+ Nueva evaluación"}
      </button>

      <div className="tabla-wrap">
        <table className="tabla">
          <thead>
            <tr>
              <th>Título</th>
              <th>Tema</th>
              <th>Preguntas</th>
              <th>Estado</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {evaluaciones.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ textAlign: "center", padding: 24 }}>
                  No hay evaluaciones. Crea la primera.
                </td>
              </tr>
            ) : (
              evaluaciones.map((e) => (
                <tr key={e.id}>
                  <td>{e.titulo}</td>
                  <td>{e.tema}</td>
                  <td>{e.numPreguntas}</td>
                  <td>
                    <span className={`badge ${e.activa ? "badge-ok" : "badge-fail"}`}>
                      {e.activa ? "Activa" : "Inactiva"}
                    </span>
                  </td>
                  <td style={{ display: "flex", gap: 8 }}>
                    <a
                      className="btn btn-secondary"
                      style={{ padding: "6px 12px", fontSize: 13 }}
                      href={`/admin/evaluaciones/${e.id}`}
                    >
                      Editar
                    </a>
                    <button
                      className="btn btn-secondary"
                      style={{ padding: "6px 12px", fontSize: 13, color: "var(--rojo)" }}
                      onClick={() => eliminar(e.id, e.titulo)}
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </>
  );
}

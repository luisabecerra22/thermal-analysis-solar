"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Evaluacion } from "@/lib/types";

const CUALITATIVAS = [
  { valor: "bueno", texto: "Bueno" },
  { valor: "regular", texto: "Regular" },
  { valor: "deficiente", texto: "Deficiente" },
];

export default function FormularioEvaluacion({
  evaluacion,
}: {
  evaluacion: Evaluacion;
}) {
  const router = useRouter();
  const [participante, setParticipante] = useState({
    correo: "",
    nombre: "",
    apellido: "",
    cedula: "",
    cargo: "",
  });
  const [respuestas, setRespuestas] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [enviando, setEnviando] = useState(false);

  function setCampo(campo: keyof typeof participante, valor: string) {
    setParticipante((p) => ({ ...p, [campo]: valor }));
  }

  function validar(): string | null {
    const { correo, nombre, apellido, cedula, cargo } = participante;
    if (!nombre.trim() || !apellido.trim()) return "Ingresa tu nombre y apellido.";
    if (!/^\S+@\S+\.\S+$/.test(correo)) return "Ingresa un correo válido.";
    if (!/^\d{5,15}$/.test(cedula.trim()))
      return "Ingresa un número de cédula válido (solo dígitos).";
    if (!cargo.trim()) return "Ingresa tu cargo.";
    for (const p of evaluacion.preguntas) {
      if (!respuestas[p.id]) return "Responde todas las preguntas de conocimiento.";
    }
    for (const f of evaluacion.feedback) {
      if (!feedback[f.id]) return "Responde todas las preguntas de retroalimentación.";
    }
    return null;
  }

  async function enviar() {
    const errValidacion = validar();
    if (errValidacion) {
      setError(errValidacion);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setError(null);
    setEnviando(true);
    try {
      const res = await fetch("/api/attempts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          evaluacionId: evaluacion.id,
          participante: {
            ...participante,
            correo: participante.correo.trim().toLowerCase(),
            cedula: participante.cedula.trim(),
          },
          respuestas,
          feedback: Object.entries(feedback).map(([preguntaId, valor]) => ({
            preguntaId,
            valor,
          })),
        }),
      });
      const data = await res.json();
      if (res.status === 429) {
        setError(data.mensaje);
        setEnviando(false);
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      if (!res.ok) throw new Error(data.error || "Error al enviar.");
      router.push(`/resultado/${data.id}`);
    } catch (e) {
      setError((e as Error).message);
      setEnviando(false);
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}

      {/* Registro */}
      <div className="card">
        <h2>Tus datos</h2>
        <div className="grid-2">
          <div className="field">
            <label>Nombre</label>
            <input
              value={participante.nombre}
              onChange={(e) => setCampo("nombre", e.target.value)}
              placeholder="Ej. María"
            />
          </div>
          <div className="field">
            <label>Apellido</label>
            <input
              value={participante.apellido}
              onChange={(e) => setCampo("apellido", e.target.value)}
              placeholder="Ej. Gómez"
            />
          </div>
        </div>
        <div className="grid-2">
          <div className="field">
            <label>Número de identificación (cédula)</label>
            <input
              inputMode="numeric"
              value={participante.cedula}
              onChange={(e) => setCampo("cedula", e.target.value)}
              placeholder="Solo números"
            />
          </div>
          <div className="field">
            <label>Cargo</label>
            <input
              value={participante.cargo}
              onChange={(e) => setCampo("cargo", e.target.value)}
              placeholder="Ej. Operario"
            />
          </div>
        </div>
        <div className="field">
          <label>Correo electrónico</label>
          <input
            type="email"
            value={participante.correo}
            onChange={(e) => setCampo("correo", e.target.value)}
            placeholder="tucorreo@ejemplo.com"
          />
        </div>
      </div>

      {/* Preguntas de conocimiento */}
      <div className="card">
        <h2>Evaluación de conocimiento</h2>
        {evaluacion.preguntas.map((p, i) => (
          <div className="pregunta" key={p.id}>
            <div className="enunciado">
              {i + 1}. {p.enunciado}
            </div>
            {p.opciones.map((o) => {
              const sel = respuestas[p.id] === o.id;
              return (
                <label
                  key={o.id}
                  className={`opcion ${sel ? "seleccionada" : ""}`}
                >
                  <input
                    type="radio"
                    name={p.id}
                    checked={sel}
                    onChange={() =>
                      setRespuestas((r) => ({ ...r, [p.id]: o.id }))
                    }
                  />
                  <span>
                    <strong>{o.id})</strong> {o.texto}
                  </span>
                </label>
              );
            })}
          </div>
        ))}
      </div>

      {/* Retroalimentación */}
      <div className="card">
        <h2>Evaluación del capacitador y del lugar</h2>
        <p className="muted" style={{ marginTop: 0 }}>
          Esta sección es retroalimentación y no afecta tu calificación.
        </p>
        {evaluacion.feedback.map((f) => (
          <div className="pregunta" key={f.id}>
            <div className="enunciado">{f.enunciado}</div>
            {f.escala === "cualitativa" ? (
              <div className="escala-num">
                {CUALITATIVAS.map((c) => (
                  <label key={c.valor}>
                    <input
                      type="radio"
                      name={f.id}
                      checked={feedback[f.id] === c.valor}
                      onChange={() =>
                        setFeedback((r) => ({ ...r, [f.id]: c.valor }))
                      }
                    />
                    {c.texto}
                  </label>
                ))}
              </div>
            ) : (
              <div className="escala-num">
                {[1, 2, 3, 4, 5].map((n) => (
                  <label key={n}>
                    <input
                      type="radio"
                      name={f.id}
                      checked={feedback[f.id] === String(n)}
                      onChange={() =>
                        setFeedback((r) => ({ ...r, [f.id]: String(n) }))
                      }
                    />
                    {n}
                  </label>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      <button
        className="btn btn-primary btn-block"
        onClick={enviar}
        disabled={enviando}
      >
        {enviando ? "Enviando…" : "Enviar evaluación"}
      </button>
    </div>
  );
}

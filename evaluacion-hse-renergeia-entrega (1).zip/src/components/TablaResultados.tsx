"use client";

import { useMemo, useState } from "react";
import type { Evaluacion, Intento } from "@/lib/types";

function fechaCorta(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("es-CO", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function TablaResultados({
  intentos,
  evaluaciones,
}: {
  intentos: Intento[];
  evaluaciones: Evaluacion[];
}) {
  const [fEval, setFEval] = useState("");
  const [fEstado, setFEstado] = useState("");
  const [busqueda, setBusqueda] = useState("");
  const [detalle, setDetalle] = useState<Intento | null>(null);

  const evalPorId = useMemo(
    () => new Map(evaluaciones.map((e) => [e.id, e])),
    [evaluaciones],
  );

  const filtrados = useMemo(() => {
    const q = busqueda.trim().toLowerCase();
    return intentos.filter((i) => {
      if (fEval && i.evaluacionId !== fEval) return false;
      if (fEstado === "aprobado" && !i.aprobado) return false;
      if (fEstado === "reprobado" && i.aprobado) return false;
      if (q) {
        const txt =
          `${i.participante.nombre} ${i.participante.apellido} ${i.participante.cedula} ${i.participante.correo}`.toLowerCase();
        if (!txt.includes(q)) return false;
      }
      return true;
    });
  }, [intentos, fEval, fEstado, busqueda]);

  function exportar() {
    const params = new URLSearchParams();
    if (fEval) params.set("evaluacion", fEval);
    if (fEstado) params.set("estado", fEstado);
    if (busqueda.trim()) params.set("q", busqueda.trim());
    window.location.href = `/api/admin/export?${params.toString()}`;
  }

  return (
    <>
      <div className="toolbar">
        <div className="field">
          <label>Evaluación</label>
          <select value={fEval} onChange={(e) => setFEval(e.target.value)}>
            <option value="">Todas</option>
            {evaluaciones.map((e) => (
              <option key={e.id} value={e.id}>
                {e.titulo}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>Estado</label>
          <select value={fEstado} onChange={(e) => setFEstado(e.target.value)}>
            <option value="">Todos</option>
            <option value="aprobado">Aprobados</option>
            <option value="reprobado">Reprobados</option>
          </select>
        </div>
        <div className="field" style={{ flex: 1, minWidth: 200 }}>
          <label>Buscar (nombre, cédula, correo)</label>
          <input
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Escribe para filtrar…"
          />
        </div>
        <button className="btn btn-primary" onClick={exportar}>
          Exportar a Excel (CSV)
        </button>
      </div>

      <p className="muted">
        {filtrados.length} de {intentos.length} registros
      </p>

      <div className="tabla-wrap">
        <table className="tabla">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Nombre</th>
              <th>Cédula</th>
              <th>Cargo</th>
              <th>Correo</th>
              <th>Evaluación</th>
              <th>Nota</th>
              <th>Estado</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtrados.length === 0 ? (
              <tr>
                <td colSpan={9} style={{ textAlign: "center", padding: 24 }}>
                  Sin registros.
                </td>
              </tr>
            ) : (
              filtrados.map((i) => (
                <tr key={i.id}>
                  <td>{fechaCorta(i.presentadoEn)}</td>
                  <td>
                    {i.participante.nombre} {i.participante.apellido}
                  </td>
                  <td>{i.participante.cedula}</td>
                  <td>{i.participante.cargo}</td>
                  <td>{i.participante.correo}</td>
                  <td>{i.evaluacionTitulo}</td>
                  <td>
                    <strong>{i.nota.toFixed(1)}</strong>
                  </td>
                  <td>
                    <span
                      className={`badge ${i.aprobado ? "badge-ok" : "badge-fail"}`}
                    >
                      {i.aprobado ? "Aprobado" : "Reprobado"}
                    </span>
                  </td>
                  <td>
                    <button
                      className="btn btn-secondary"
                      style={{ padding: "6px 12px", fontSize: 13 }}
                      onClick={() => setDetalle(i)}
                    >
                      Ver
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {detalle && (
        <DetalleModal
          intento={detalle}
          evaluacion={evalPorId.get(detalle.evaluacionId)}
          onClose={() => setDetalle(null)}
        />
      )}
    </>
  );
}

function DetalleModal({
  intento,
  evaluacion,
  onClose,
}: {
  intento: Intento;
  evaluacion?: Evaluacion;
  onClose: () => void;
}) {
  const fbTexto = new Map(
    (evaluacion?.feedback ?? []).map((f) => [f.id, f.enunciado]),
  );

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.5)",
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "center",
        padding: 20,
        zIndex: 50,
        overflowY: "auto",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="card"
        style={{ maxWidth: 640, width: "100%", marginTop: 40 }}
      >
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <h2 style={{ marginBottom: 4 }}>
            {intento.participante.nombre} {intento.participante.apellido}
          </h2>
          <button className="btn btn-secondary" onClick={onClose}>
            Cerrar
          </button>
        </div>
        <p className="muted" style={{ marginTop: 0 }}>
          C.C. {intento.participante.cedula} · {intento.participante.cargo} ·{" "}
          {intento.participante.correo}
        </p>
        <p>
          <strong>{intento.evaluacionTitulo}</strong> — Nota{" "}
          <strong>{intento.nota.toFixed(1)}</strong> (
          {intento.aciertos}/{intento.totalPreguntas}) ·{" "}
          <span className={`badge ${intento.aprobado ? "badge-ok" : "badge-fail"}`}>
            {intento.aprobado ? "Aprobado" : "Reprobado"}
          </span>
        </p>

        <h2 style={{ fontSize: 16, marginTop: 22 }}>
          Respuestas de conocimiento
        </h2>
        {(evaluacion?.preguntas ?? []).map((p, i) => {
          const elegida = intento.respuestas[p.id];
          const ok = elegida === p.correcta;
          return (
            <div key={p.id} style={{ marginBottom: 10, fontSize: 14 }}>
              <div style={{ fontWeight: 600 }}>
                {i + 1}. {p.enunciado}
              </div>
              <div style={{ color: ok ? "var(--verde-osc)" : "var(--rojo)" }}>
                Respondió: {elegida ?? "—"}{" "}
                {ok ? "✓" : `✗ (correcta: ${p.correcta})`}
              </div>
            </div>
          );
        })}

        <h2 style={{ fontSize: 16, marginTop: 22 }}>
          Retroalimentación del capacitador
        </h2>
        {intento.feedback.length === 0 ? (
          <p className="muted">Sin retroalimentación registrada.</p>
        ) : (
          intento.feedback.map((f) => (
            <div key={f.preguntaId} style={{ marginBottom: 8, fontSize: 14 }}>
              <span style={{ fontWeight: 600 }}>
                {fbTexto.get(f.preguntaId) ?? f.preguntaId}:
              </span>{" "}
              {f.valor}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
